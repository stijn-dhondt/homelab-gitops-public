# Wandeldashboard — Dodentocht 2027

Kleine Node.js-app die je Health Auto Export CSV's inleest en op de server
bewaart (in `/app/data`, als JSON-bestand per persoon), zodat het dashboard
overal hetzelfde toont, ongeacht toestel.

## In Portainer deployen (Stacks)

1. Ga in Portainer naar **Stacks → Add stack**.
2. Kies **Repository** en verwijs naar de map met deze bestanden (of **Upload**
   het volledige projectmapje als zip), of plak de inhoud van
   `docker-compose.yml` rechtstreeks in de webeditor.
3. Deploy de stack. Portainer bouwt de image en start de container.
4. Test lokaal: `http://<server-ip>:3000` moet het dashboard tonen.

## dodentocht.tine-stijn.be koppelen

Dit hangt af van je reverse proxy:

- **Traefik**: schakel de labels in `docker-compose.yml` in (verwijder de
  `#`), pas `certresolver`/`entrypoints` aan naar jouw Traefik-config, en
  zorg dat Traefik hetzelfde Docker-netwerk ziet als deze container.
- **Nginx Proxy Manager**: laat de poortmapping `3000:3000` staan, maak in
  NPM een nieuwe proxy host aan voor `dodentocht.tine-stijn.be` die
  doorverwijst naar `<server-ip>:3000`, met SSL via Let's Encrypt.
- **Iets anders**: zolang je reverse proxy naar poort 3000 van deze
  container kan doorverwijzen, werkt het.

Vergeet niet een DNS A/CNAME-record voor `dodentocht.tine-stijn.be` te zetten
naar je server/reverse proxy, als dat nog niet het geval is.

## Data

Sessies worden weggeschreven naar `/app/data/sessions-you.json` en
`/app/data/sessions-step.json`. Dat pad zit op het Docker volume
`wandeldashboard-data`, dus het overleeft een herstart of herbouw van de
container.
