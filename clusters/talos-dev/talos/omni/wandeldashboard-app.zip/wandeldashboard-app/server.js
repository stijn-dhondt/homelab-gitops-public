const express = require('express');
const path = require('path');
const fs = require('fs');

const app = express();
app.use(express.json({ limit: '5mb' }));
app.use(express.static(path.join(__dirname, 'public')));

const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const ALLOWED_PERSONS = ['you', 'step'];

function dataFile(person) {
  return path.join(DATA_DIR, `sessions-${person}.json`);
}

function readSessions(person) {
  const f = dataFile(person);
  if (!fs.existsSync(f)) return [];
  try {
    return JSON.parse(fs.readFileSync(f, 'utf-8'));
  } catch (e) {
    return [];
  }
}

function writeSessions(person, sessions) {
  fs.writeFileSync(dataFile(person), JSON.stringify(sessions, null, 2));
}

function checkPerson(req, res, next) {
  if (!ALLOWED_PERSONS.includes(req.params.person)) {
    return res.status(400).json({ error: 'Onbekende persoon' });
  }
  next();
}

app.get('/api/sessions/:person', checkPerson, (req, res) => {
  res.json(readSessions(req.params.person));
});

app.post('/api/sessions/:person', checkPerson, (req, res) => {
  const incoming = Array.isArray(req.body.sessions) ? req.body.sessions : [];
  const existing = readSessions(req.params.person);

  const seen = new Set(existing.map((s) => s.date + '|' + s.km));
  const merged = existing.slice();

  incoming.forEach((s) => {
    if (!s || typeof s.date !== 'string' || typeof s.km !== 'number') return;
    const key = s.date + '|' + s.km;
    if (!seen.has(key)) {
      merged.push({ date: s.date, km: Math.round(s.km * 100) / 100 });
      seen.add(key);
    }
  });

  merged.sort((a, b) => a.date.localeCompare(b.date));
  writeSessions(req.params.person, merged);
  res.json(merged);
});

app.delete('/api/sessions/:person', checkPerson, (req, res) => {
  writeSessions(req.params.person, []);
  res.json([]);
});

app.get('/health', (req, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Wandeldashboard draait op poort ${PORT}`));
